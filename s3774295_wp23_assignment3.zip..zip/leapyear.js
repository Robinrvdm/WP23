document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');

    form.addEventListener('input', function(event) {
        validateInput(event.target);
    });

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        if (validateForm()) {
            form.submit();
        }
    });

    function validateInput(input) {
        const value = input.value.trim();
        const feedback = input.nextElementSibling;

        if (value === '') {
            input.classList.remove('is-valid');
            input.classList.add('is-invalid');
            feedback.style.display = 'block';
        } else {
            input.classList.remove('is-invalid');
            input.classList.add('is-valid');
            feedback.style.display = 'none';
        }
    }

    function validateForm() {
        const inputs = form.querySelectorAll('input');

        for (let i = 0; i < inputs.length; i++) {
            validateInput(inputs[i]);

            if (inputs[i].classList.contains('is-invalid')) {
                return false;
            }
        }

        return true;
    }
});
