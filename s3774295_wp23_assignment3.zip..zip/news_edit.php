<!DOCTYPE html>
<html>
<head>
    <?php include("tpl/head.php"); ?>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include("tpl/body_start.php"); ?>

    <div class="container">
        <h1>Edit News Item</h1>
        <form id="edit-item-form">
            <input type="hidden" id="id" name="id" value="<?php echo $_GET['id']; ?>">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="content">Content:</label>
                <textarea class="form-control" id="content" name="content" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="scripts/news_edit.js"></script>

    <?php include("tpl/body_end.php"); ?>
</body>
</html>
