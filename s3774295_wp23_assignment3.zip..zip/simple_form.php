<?php
/* Header */
$page_title = 'Webprogramming Assignment 3';
$navigation = Array(
    'active' => 'Simple Form',
    'items' => Array(
        'News' => '/WP22/assignment_3/index.php',
        'Add news item' => '/WP22/assignment_3/news_add.php',
        'Leap Year' => '/WP22/assignment_3/leapyear.php',
        'Simple Form' => '/WP22/assignment_3/simple_form.php'
    )
);
include __DIR__ . '/tpl/head.php';
include __DIR__ . '/tpl/body_start.php';
?>

<!DOCTYPE html>
<html>
<head>
    <?php include("tpl/head.php"); ?>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include("tpl/body_start.php"); ?>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <form method="GET" action="simple_form.php">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                    <div class="form-group">
                        <label for="place">Place/Residence:</label>
                        <input type="text" class="form-control" id="place" name="place">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>

                <?php
                if (isset($_GET['name'])) {
                    $name = $_GET['name'];
                    echo "<h1>Welcome $name!</h1>";

                    if ($_GET['place'] === 'Amsterdam') {
                        echo "<p>You're from the capital of the Netherlands!</p>";
                    } else {
                        $place = $_GET['place'];
                        echo "<p>You're from $place!</p>";
                    }
                }
                ?>
            </div>
        </div>
    </div>

    <?php include("tpl/body_end.php"); ?>
</body>
</html>

<?php include __DIR__ . '/tpl/body_end.php'; ?>

