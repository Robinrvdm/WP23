<!DOCTYPE html>
<html>
<head>
    <?php include("tpl/head.php"); ?>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include("tpl/body_start.php"); ?>

    <div class="container">
        <h1>News Overview</h1>
        <div id="news-container"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="scripts/read_latest_news.js"></script>
    <script src="scripts/news_remove.js"></script>

    <?php include("tpl/body_end.php"); ?>
</body>
</html>
