<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $editDate = date('Y-m-d');
    $articles = json_decode(file_get_contents("website.json"), true);

    $newItem = [
        "id" => count($articles) + 1,
        "title" => $title,
        "content" => $content,
        "edit_date" => $editDate
    ];

    $articles[] = $newItem;

    file_put_contents("website.json", json_encode($articles));

    echo json_encode($newItem);
}
?>
