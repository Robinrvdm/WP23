<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    $editDate = date('Y-m-d');
    $articles = json_decode(file_get_contents("website.json"), true);

    foreach ($articles as &$article) {
        if ($article['id'] == $id) {
            $article['title'] = $title;
            $article['content'] = $content;
            $article['edit_date'] = $editDate;
            break;
        }
    }

    file_put_contents("website.json", json_encode($articles));

    echo json_encode($articles);
}
?>
