<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $articles = json_decode(file_get_contents("website.json"), true);

    $filtered = array_filter($articles, function($article) use ($id) {
        return $article['id'] != $id;
    });

    file_put_contents("data/articles.json", json_encode(array_values($filtered)));

    echo "success";
}
?>
