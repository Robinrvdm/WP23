<!DOCTYPE html>
<html>
<head>
    <?php include("tpl/head.php"); ?>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include("tpl/body_start.php"); ?>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <form method="POST" action="leapyear.php">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please enter a name.</div>
                    </div>
                    <div class="form-group">
                        <label for="age">Age:</label>
                        <input type="number" class="form-control" id="age" name="age" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please enter a valid age.</div>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please enter a valid email address.</div>
                    </div>
                    <div class="form-group">
                        <label for="place">Place/Residence:</label>
                        <input type="text" class="form-control" id="place" name="place" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please enter a place of residence.</div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>

                <?php
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $name = $_POST['name'];
                    $age = $_POST['age'];
                    $place = $_POST['place'];
                    $leapYears = [];
                    $currentYear = date('Y');

                    for ($i = 1; $i <= 5; $i++) {
                        $leapYear = $currentYear + ($i * 4);
                        $leapYears[] = $leapYear;
                    }

                    echo "<h2>Welcome, $name!</h2>";
                    echo "<p>Your place of residence: $place</p>";

                    if ($place === 'Groningen') {
                        echo "<p>Moi, leuk dat je er bent!</p>";
                    }

                    echo "<table class='table'>";
                    echo "<thead><tr><th>Leap Year</th><th>Age</th></tr></thead>";
                    echo "<tbody>";
                    foreach ($leapYears as $year) {
                        $ageInYear = $age + ($year - $currentYear);
                        echo "<tr><td>$year</td><td>$ageInYear</td></tr>";
                    }
                    echo "</tbody></table>";
                }
                ?>
            </div>
        </div>
    </div>

    <script src="scripts/leapyear.js"></script>

    <?php include("tpl/body_end.php"); ?>
</body>
</html>
