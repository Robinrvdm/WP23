<?php
$articles = json_decode(file_get_contents("website.json"), true);

if (!empty($articles)) {
    usort($articles, function($a, $b) {
        return strtotime($b['edit_date']) - strtotime($a['edit_date']);
    });

    foreach ($articles as $article) {
        echo "<div class='card'>";
        echo "<div class='card-body'>";
        echo "<h5 class='card-title'>" . $article['title'] . "</h5>";
        echo "<p class='card-text'>" . $article['content'] . "</p>";
        echo "<p class='card-text'><small class='text-muted'>Last updated: " . $article['edit_date'] . "</small></p>";
        echo "<button class='btn btn-danger' data-id='" . $article['id'] . "'>Remove</button>";
        echo "</div>";
        echo "</div>";
    }
}
?>
