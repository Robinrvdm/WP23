window.addEventListener('load', () => {
  
// Changes the titles of the webpages.
document.title = "Webprogramming (LIX018P05) - Index";
document.title = "Webprogramming (LIX018P05) - Second";

// Add a new article to the main column of the index.html page
const mainCol = document.querySelector('.col-md-12');
const newArticle = document.createElement('article');
newArticle.innerHTML = '<h1>This is a new article</h1><p>This is a paragraph.</p>';
mainCol.appendChild(newArticle);

// Change the href attribute of the <a> element inside the third <li> element inside the <div> with id="links" to google.com
const linksDiv = document.getElementById('links');
const thirdLi = linksDiv.querySelector('li:nth-child(3)');
const link = thirdLi.querySelector('a');
link.href = 'https://google.com';

// Add an attribute to the <a> from the previous step
link.setAttribute('target', '_blank');

// Select all elements with the class nav-item. Change the text color of these element to red
const navItems = document.querySelectorAll('.nav-item');
navItems.forEach(navItem => navItem.style.color = 'red');

// Make a schedule for the data provided in the wp23-check
const schedule = {
  'Week 1': 'Assignment 1',
  'Week 2': 'Assignment 1',
  'Week 3': 'Assignment 2',
  'Week 4': 'Assignment 2',
  'Week 5': 'Assignment 3',
  'Week 6': 'Assignment 3',
  'Week 7': 'Final Project'
};

const scheduleContainer = document.createElement('div');
for (const week in schedule) {
  const assignment = schedule[week];
  const scheduleEntry = document.createElement('p');
  scheduleEntry.innerHTML = `${week} - ${assignment}`;
  scheduleContainer.appendChild(scheduleEntry);
}
mainCol.appendChild(scheduleContainer);


// Add a sidebar to second.html
const mainColSecond = document.querySelector('.col-md-12');
mainColSecond.classList.replace('col-md-12', 'col-md-8');
const newSidebar = document.createElement('div');
newSidebar.classList.add('col-md-4');
const sidebarHeading = document.createElement('h2');
sidebarHeading.textContent = 'Sidebar';
newSidebar.appendChild(sidebarHeading);
mainColSecond.insertAdjacentElement('afterend', newSidebar);

});